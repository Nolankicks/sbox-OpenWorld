using Sandbox;

/// <summary>
/// This is a component - in your library!
/// </summary>
[Title( "Quick Switcher - My Component" )]
public class MyLibraryComponent : Component
{

}
